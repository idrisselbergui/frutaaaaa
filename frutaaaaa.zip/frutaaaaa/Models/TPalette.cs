﻿public class TPalette
{
    public string codtyp { get; set; }
    public string nomemb { get; set; }
}