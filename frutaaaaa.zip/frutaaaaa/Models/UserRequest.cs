﻿namespace frutaaaaa.Models
{
    public class UserRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public int Permission { get; set; }
    }
}