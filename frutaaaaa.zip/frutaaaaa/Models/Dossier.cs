﻿namespace frutaaaaa.Models
{
    public class Dossier
    {
        public int numdos { get; set; }
        public int? coddes { get; set; }
        // Ajoutez d'autres propriétés si nécessaire
    }
}