﻿namespace frutaaaaa.Models
{
    public class Verger
    {
        public int refver { get; set; }
        public int? refadh { get; set; }
        public string nomver { get; set; }
    }
}