﻿public class Destination
{
    public int coddes { get; set; }
    public string vildes { get; set; }
}