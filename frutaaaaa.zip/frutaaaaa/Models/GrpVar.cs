﻿public class GrpVar
{
    public int codgrv { get; set; }
    public string nomgrv { get; set; }
}