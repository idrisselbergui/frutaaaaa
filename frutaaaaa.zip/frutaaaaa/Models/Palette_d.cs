﻿namespace frutaaaaa.Models
{
    public class Palette_d
    {
        public int? numpal { get; set; }
        public int? nbrcol { get; set; }
        public int? nbrfru { get; set; }
        public int? refver { get; set; }
        public decimal? pdscom { get; set; }
        public decimal? pdsfru { get; set; }
        public int? numbdq { get; set; }
        public int? codvar { get; set; }
    }
}