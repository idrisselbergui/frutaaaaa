﻿public class Partenaire
{
    public int @ref { get; set; }
    public string nom { get; set; }
    public string type { get; set; }
}