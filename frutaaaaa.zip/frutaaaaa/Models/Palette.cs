﻿using System;
using System.Collections.Generic;

namespace frutaaaaa.Models
{
    public class Palette
    {
        public int numpal { get; set; }
        public DateTime? dtepal { get; set; }
        public int? colpal { get; set; }
        public decimal? pdscom { get; set; }
        public decimal? pdsfru { get; set; }
        public string codtyp { get; set; }
        public int? numbdq { get; set; }
        public int? codmar { get; set; }
        public int? codvar { get; set; }
        public int? codgrp { get; set; }
        public int? codexp { get; set; }

       
    }
}