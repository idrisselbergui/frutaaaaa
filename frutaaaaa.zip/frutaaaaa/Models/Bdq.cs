﻿namespace frutaaaaa.Models
{
    public class Bdq
    {
        public int numbdq { get; set; }
        public int? numdos { get; set; }
        // Ajoutez d'autres propriétés si nécessaire
    }
}