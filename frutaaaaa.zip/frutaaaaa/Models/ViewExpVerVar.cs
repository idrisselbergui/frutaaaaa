﻿namespace frutaaaaa.Models
{
    public class ViewExpVerVar
    {
        public int refver { get; set; }
        public int codvar { get; set; }
        public int coddes { get; set; }
        public decimal pdscom { get; set; } // Le nom de la colonne SUM
    }
}