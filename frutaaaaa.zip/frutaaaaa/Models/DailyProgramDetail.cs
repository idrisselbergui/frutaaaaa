﻿public class DailyProgramDetail
{
    public int NumProg { get; set; }
    // public int Codvar { get; set; } // Remove this line
    public int codgrv { get; set; }   // Add this line
    public string codtyp { get; set; }
    public int Nbrpal { get; set; }
    public int Nbrcoli { get; set; }
    public int Valide { get; set; }
}