﻿namespace frutaaaaa.Models
{
    public class Variete
    {
        public int codvar { get; set; }
        public string nomvar { get; set; }


    }
}
